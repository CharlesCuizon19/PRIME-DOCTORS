<header class="relative z-50 shadow drop-shadow-md">
    <!-- Top Bar -->
    

    <!-- Logo + Nav -->
    <div>
        <div class="relative">
            <img src="<?php echo e(asset('assets/header-bg.png')); ?>" alt="" class="w-full h-[7rem] z-10">

            <div class="container absolute inset-0 top-0 z-50 flex items-center justify-between mx-auto">
                <!-- Logo -->
                <div class="flex items-center space-x-4">
                    <img src="<?php echo e(asset('assets/logo.png')); ?>" alt="Logo" class="h-20 lg:h-20">
                </div>

                <!-- Desktop Nav -->
                <nav class="hidden space-x-6 md:flex">
                    <a href="<?php echo e(route('home')); ?>"
                        class="<?php echo e(Route::is('home') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?> px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                        Home </a>
                    <a href="<?php echo e(route('about-us')); ?>"
                        class="<?php echo e(Route::is('about-us') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?> px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">About
                        Us</a>
                    <a href="<?php echo e(route('services')); ?>"
                        class="<?php echo e(Route::is('service.*') || Route::is('services') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?> px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">Services</a>
                    <a href="<?php echo e(route('careers')); ?>"
                        class="<?php echo e(Route::is('careers.*') || Route::is('careers') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?> px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">Careers</a>
                    <a href="<?php echo e(route('find-a-doctor.show')); ?>"
                        class="<?php echo e(Route::is('find-a-doctor.*') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?> px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                        Find a Doctor</a>
                    <a href="<?php echo e(route('news-and-events.show')); ?>"
                        class="<?php echo e(Route::is('news-and-events.*') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?> px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">News
                        & Events</a>
                    <a href="<?php echo e(route('contact-us.show')); ?>"
                        class="<?php echo e(Route::is('contact-us.*') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?> px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">Contact
                        Us</a>
                </nav>

                <!-- Mobile Menu Button -->
                <button id="menu-btn" class="text-gray-600 md:hidden focus:outline-none">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8" fill="none" viewBox="0 0 24 24"
                        stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                </button>
            </div>

        </div>

        <!-- Mobile Nav -->
        <div id="menu" class="flex-col hidden px-6 pb-4 space-y-2 md:hidden bg-gray-50">
            <div>
                <a href="<?php echo e(route('home')); ?>"
                    class="<?php echo e(Route::is('home') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?>  block px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                    Home </a>
                <a href="<?php echo e(route('about-us')); ?>"
                    class="<?php echo e(Route::is('about-us') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?>  block px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                    About Us </a>
                <a href="<?php echo e(route('services')); ?>"
                    class="<?php echo e(Route::is('service.*') || Route::is('services') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?>  block px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                    Services </a>
                <a href="<?php echo e(route('careers')); ?>"
                    class="<?php echo e(Route::is('careers.*') || Route::is('careers') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?>  block px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                    Careers </a>
                <a href="<?php echo e(route('find-a-doctor.show')); ?>"
                    class="<?php echo e(Route::is('find-a-doctor.*') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?>  block px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                    Find a Doctor </a>
                <a href="<?php echo e(route('news-and-events.show')); ?>"
                    class="<?php echo e(Route::is('news-and-events.*') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?>  block px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                    New & Events </a>
                <a href="<?php echo e(route('contact-us.show')); ?>"
                    class="<?php echo e(Route::is('contact-us.*') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?>  block px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                    Contact Us</a>
            </div>

            <!-- Features + Hotline -->
            <div class="bg-gray-50">
                <div
                    class="container flex flex-col items-center justify-between px-6 mx-auto space-y-4 lg:flex-row lg:space-y-0">
                    <div class="flex items-center justify-center text-gray-800 gap-14">
                        <div class="flex items-center space-x-2">
                            <img src="<?php echo e(asset('assets/icon1.png')); ?>" class="w-6 h-6">
                            <span class="text-sm font-bold lg:text-sm">24/7 Emergency Services</span>
                        </div>
                        <div class="flex items-center space-x-2">
                            <img src="<?php echo e(asset('assets/icon2.png')); ?>" class="w-6 h-6">
                            <span class="text-sm font-bold lg:text-sm">Specialized Doctors</span>
                        </div>
                        <div class="flex items-center space-x-2">
                            <img src="<?php echo e(asset('assets/icon3.png')); ?>" class="w-6 h-6">
                            <span class="text-sm font-bold lg:text-sm">Patient-Centric Care</span>
                        </div>
                    </div>

                    <div
                        class="flex items-center w-full max-w-xs px-5 py-3 space-x-4 text-white bg-blue-600 rounded-lg shadow sm:w-auto">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="h-8">
                            <path fill="currentColor"
                                d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24c1.12.37 2.33.57 3.57.57c.55 0 1 .45 1 1V20c0 .55-.45 1-1 1c-9.39 0-17-7.61-17-17c0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1c0 1.25.2 2.45.57 3.57c.11.35.03.74-.25 1.02z" />
                        </svg>
                        <span class="text-xl font-bold sm:text-2xl">0917 327 7463</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Features + Hotline -->
    
</header>


<header id="header"
    class="fixed top-0 z-50 w-full transition-all duration-300 ease-out transform -translate-y-full opacity-0">

    <!-- Logo + Nav -->
    <div class="">
        <div class="relative">
            <img src="<?php echo e(asset('assets/header-bg.png')); ?>" alt="" class="w-full h-[7rem] z-10">

            <div class="container absolute inset-0 flex items-center justify-between mx-auto">
                <!-- Logo -->
                <div class="flex items-center space-x-4">
                    <img src="<?php echo e(asset('assets/logo.png')); ?>" alt="Logo" class="h-20 sm:h-20">
                </div>

                <!-- Desktop Nav -->
                <nav class="hidden space-x-6 md:flex">
                    <a href="<?php echo e(route('home')); ?>"
                        class="<?php echo e(Route::is('home') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?> px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                        Home </a>
                    <a href="<?php echo e(route('about-us')); ?>"
                        class="<?php echo e(Route::is('about-us') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?>  px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                        About Us </a>
                    <a href="<?php echo e(route('services')); ?>"
                        class="<?php echo e(Route::is('service.*') || Route::is('services') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?>  px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                        Services </a>
                    <a href="<?php echo e(route('careers')); ?>"
                        class="<?php echo e(Route::is('careers.*') || Route::is('careers') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?>  px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                        Careers </a>
                    <a href="<?php echo e(route('find-a-doctor.show')); ?>"
                        class="<?php echo e(Route::is('find-a-doctor.*') || Route::is('careers') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?>  px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                        Find a Doctor
                    </a>
                    <a href="<?php echo e(route('news-and-events.show')); ?>"
                        class="<?php echo e(Route::is('news-and-events.*') || Route::is('careers') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?>  px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                        News & Events
                    </a>
                    <a href="<?php echo e(route('contact-us.show')); ?>"
                        class="<?php echo e(Route::is('contact-us.*') || Route::is('careers') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?>  px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                        Contact Us
                    </a>
                </nav>

                <!-- Mobile Menu Button -->
                <button id="menu-btn2" class="text-gray-600 md:hidden focus:outline-none">
                    <svg xmlns="http://www.w3.org/2000/svg" class="w-8 h-8" fill="none" viewBox="0 0 24 24"
                        stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                </button>
            </div>

        </div>
    </div>

    

    <!-- Mobile Nav -->
    <div id="menu2" class="flex-col hidden px-6 pb-4 space-y-2 md:hidden bg-gray-50">
        <div>
            <a href="<?php echo e(route('home')); ?>"
                class="<?php echo e(Route::is('home') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?>  block px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                Home </a>
            <a href="<?php echo e(route('about-us')); ?>"
                class="<?php echo e(Route::is('about-us') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?>  block px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                About Us </a>
            <a href="<?php echo e(route('services')); ?>"
                class="<?php echo e(Route::is('services') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?>  block px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                Services </a>
            <a href="<?php echo e(route('careers')); ?>"
                class="<?php echo e(Route::is('careers') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?>  block px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                Careers </a>
            <a href="#"
                class="<?php echo e(Route::is('#') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?>  block px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                Find a Doctor </a>
            <a href="#"
                class="<?php echo e(Route::is('#') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?>  block px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                New & Events </a>
            <a href="#"
                class="<?php echo e(Route::is('#') ? 'bg-gray-200 rounded-full text-blue-700 font-semibold border-2 border-[#edb42f]' : ' text-white'); ?>  block px-3 py-1 hover:text-gray-500 hover:bg-white rounded-full transition duration-300">
                Contact Us</a>
        </div>

        <!-- Features + Hotline -->
        <div class="bg-gray-50">
            <div
                class="container flex flex-col items-center justify-between px-6 mx-auto space-y-4 lg:flex-row lg:space-y-0">
                <div class="flex items-center justify-center gap-6 text-gray-800">
                    <div class="flex items-center space-x-2">
                        <img src="<?php echo e(asset('assets/icon1.png')); ?>" class="w-6 h-6">
                        <span class="text-sm font-bold lg:text-xl">24/7 Emergency Services</span>
                    </div>
                    <div class="flex items-center space-x-2">
                        <img src="<?php echo e(asset('assets/icon2.png')); ?>" class="w-6 h-6">
                        <span class="text-sm font-bold lg:text-xl">Specialized Doctors</span>
                    </div>
                    <div class="flex items-center space-x-2">
                        <img src="<?php echo e(asset('assets/icon3.png')); ?>" class="w-6 h-6">
                        <span class="text-sm font-bold lg:text-xl">Patient-Centric Care</span>
                    </div>
                </div>

                <div
                    class="flex items-center w-full max-w-xs px-5 py-3 space-x-4 text-white bg-blue-600 rounded-lg shadow sm:w-auto">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="h-8">
                        <path fill="currentColor"
                            d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24c1.12.37 2.33.57 3.57.57c.55 0 1 .45 1 1V20c0 .55-.45 1-1 1c-9.39 0-17-7.61-17-17c0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1c0 1.25.2 2.45.57 3.57c.11.35.03.74-.25 1.02z" />
                    </svg>
                    <span class="text-xl font-bold sm:text-2xl">0917 327 7463</span>
                </div>
            </div>
        </div>
    </div>
</header>

<style>
    /* Animation for slide down */
    @keyframes slideDown {
        from {
            transform: translateY(-100%);
            opacity: 0;
        }

        to {
            transform: translateY(0);
            opacity: 1;
        }
    }

    .animate-slide-down {
        animation: slideDown 0.3s ease-out;
    }
</style>

<script>
    const btn = document.getElementById('menu-btn');
    const menu = document.getElementById('menu');
    btn.addEventListener('click', () => {
        menu.classList.toggle('hidden');
    });

    const btn2 = document.getElementById('menu-btn2');
    const menu2 = document.getElementById('menu2');
    btn2.addEventListener('click', () => {
        menu2.classList.toggle('hidden');
    });

    document.addEventListener('DOMContentLoaded', () => {
        const header = document.getElementById('header');

        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                header.classList.remove('-translate-y-full', 'opacity-0');
                header.classList.add('translate-y-0', 'opacity-100');
            } else {
                header.classList.remove('translate-y-0', 'opacity-100');
                header.classList.add('-translate-y-full', 'opacity-0');
            }
        });
    });
</script>
<?php /**PATH D:\charles\PRIME-DOCTORS\resources\views/partials/header.blade.php ENDPATH**/ ?>