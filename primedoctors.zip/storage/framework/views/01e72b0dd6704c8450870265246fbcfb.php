<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['img_path', 'title1', 'title2', 'page', 'breadcrumb']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['img_path', 'title1', 'title2', 'page', 'breadcrumb']); ?>
<?php foreach (array_filter((['img_path', 'title1', 'title2', 'page', 'breadcrumb']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>


<div class="mt-[6rem] lg:mt-0 pb-28">
    <div>
        <div class="hidden w-full h-auto lg:flex lg:absolute lg:h-[465px]">
            <div class="relative w-full">
                <img src="<?php echo e(asset($img_path)); ?>" alt="" class="object-cover lg:h-[465px] lg:w-full">
                <div class="absolute inset-0"></div>
            </div>
        </div>


        <!-- Overlay container -->
        <div class="container mx-auto">
            <div
                class="relative flex flex-col items-center justify-center gap-5 mx-3 mt-2 text-center lg:text-left lg:mt-0 lg:items-start">
                <div
                    class="flex flex-col items-center w-full gap-5 text-5xl font-bold lg:items-start lg:text-left lg:mt-[13rem]">
                    <div class="hidden lg:flex">
                        <p class="text-sm text-[#0035c6] lg:text-base">
                            Home / <span><?php echo e($page); ?></span>
                            <span>
                                <?php echo e($breadcrumb); ?>

                            </span>
                        </p>
                    </div>
                    <div>
                        <span class="text-[#0035c6] lg:text-[100px] pattaya-regular">
                            <?php echo e($title1); ?> <span class="text-[#edb42f] pattaya-regular"><?php echo e($title2); ?></span>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\charles\PRIME-DOCTORS\resources\views/components/banner.blade.php ENDPATH**/ ?>